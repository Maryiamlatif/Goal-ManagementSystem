﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOAD_TERM_PROJECT
{
    public partial class To_dos : Form
    {
        public To_dos()
        {
            InitializeComponent();
            BindMethod();
        }
        public To_dos(string value,string number,string goal)
        {
            InitializeComponent();
            rolenametxt.Text = value;
            combotype.Text = number;
            goaltxt.Text = goal;
           
        }

        private void BTNtodolist_Click(object sender, EventArgs e)
        {
            BTNtodolist.BackColor = Color.Red;
        }

        public void BindMethod()
        {
            DataGridViewButtonColumn editButton = new DataGridViewButtonColumn();
            editButton.FlatStyle = FlatStyle.Popup;
            editButton.HeaderText = "Edit";
            editButton.Name = "Edit";
            editButton.UseColumnTextForButtonValue = true;
            editButton.Text = "Edit";
            editButton.Width = 60;
            if (dataGridView1.Columns.Contains(editButton.Name = "Edit"))
            {

            }
            else
            {
                dataGridView1.Columns.Add(editButton);
            }

            DataGridViewButtonColumn DeleteButton = new DataGridViewButtonColumn();
            DeleteButton.FlatStyle = FlatStyle.Popup;
            DeleteButton.HeaderText = "Delete";
            DeleteButton.Name = "Delete";
            DeleteButton.UseColumnTextForButtonValue = true;
            DeleteButton.Text = "Delete";
            DeleteButton.Width = 60;
            if (dataGridView1.Columns.Contains(DeleteButton.Name = "Delete"))
            {

            }
            else
            {
                dataGridView1.Columns.Add(DeleteButton);
            }
        }

        private void To_dos_Load(object sender, EventArgs e)
        {
            Datashow();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ServiceReference1.Service1Client server = new ServiceReference1.Service1Client();
            ServiceReference1.To_Dos todo_s = new ServiceReference1.To_Dos();
            todo_s.Date = datetxt.Text;
            todo_s.Todo = todotxt.Text;
            server.addtodos(todo_s);
           
            MessageBox.Show("To_ os Added successfully");
            Datashow();
        }
        void Datashow()
        {
           ServiceReference1.Service1Client myclient = new ServiceReference1.Service1Client();
            BindingSource bds = new BindingSource();
            bds.DataSource = myclient.gettodoslist();
            dataGridView1.DataSource = bds;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == 0)
            {
                ServiceReference1.Service1Client server = new ServiceReference1.Service1Client();
                ServiceReference1.To_Dos post = new ServiceReference1.To_Dos();
                int index = e.RowIndex;
                post = server.gettodo(index);
                Edit_To_Do  edit_todo = new Edit_To_Do(post, index);
                edit_todo.Show();
                MessageBox.Show("Edit todo");
            }
          if (e.ColumnIndex == 1)
            {
                ServiceReference1.Service1Client server = new ServiceReference1.Service1Client();
                ServiceReference1.To_Dos post = new ServiceReference1.To_Dos();
                int index = e.RowIndex;
                server.Deletetodo(index);
                Datashow();
                MessageBox.Show("Todos deleted successfullly");

            }
          /*  else if (e.ColumnIndex == 0)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                ServiceReference1.Service1Client server = new ServiceReference1.Service1Client();
                ServiceReference1.To_Dos post = new ServiceReference1.To_Dos();
                int index = e.RowIndex;
                post = server.gettodo(index);
               // Goals goal = new Goals(post, index);
                //goal.Show();
                MessageBox.Show("Todos added successfully");
            }*/

        }
    }
}
