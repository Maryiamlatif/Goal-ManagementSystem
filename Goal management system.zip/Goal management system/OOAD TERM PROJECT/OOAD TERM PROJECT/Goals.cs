﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOAD_TERM_PROJECT
{
  
    public partial class Goals : Form
    {
        private ServiceReference1.Role showgoal = new ServiceReference1.Role();
        private ServiceReference1.Service1Client myserver = new ServiceReference1.Service1Client();
        int Index;
        public Goals()
        {
            InitializeComponent();
        }

        public Goals(string value,string number)
        {
            InitializeComponent();
            roletxt.Text = value;
            combotype.Text = number;
            


        }
        public Goals(ServiceReference1.Role s,int a)
        {
            showgoal = s;
            Index = a;
            InitializeComponent();
        }

        private void golasbtn_Click(object sender, EventArgs e)
        {
            ServiceReference1.Service1Client server = new ServiceReference1.Service1Client();
            ServiceReference1.Goal goal = new ServiceReference1.Goal();
            goal.Goalname = goaltxt.Text;
            goal.Type11 = combotype.Text;
            ServiceReference1.Service1Client myclient = new ServiceReference1.Service1Client();
            ServiceReference1.Role role = new ServiceReference1.Role(); 
            role.Rolename = roletxt.Text;
            role.Roletype = combotype.Text;
           
          //  ServiceReference1.Role role = new ServiceReference1.Role();
         //   role.Rolename =roletxt.Text ;
           // role.Roletype = comboBox1type.Text;
            server.addgoal(goal);
            MessageBox.Show("goals added successfully");
            goalDataShow();


                }
        public void goalDataShow()
        {
            ServiceReference1.Service1Client client = new ServiceReference1.Service1Client();
            BindingSource bds = new BindingSource();
            bds.DataSource = client.getgoalist();
            dataGridView1.DataSource = bds;

        }

        private void Goals_Load(object sender, EventArgs e)
        {
            goalDataShow();
        }

        private void goalinkbtn_Click(object sender, EventArgs e)
        {
           ;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            To_dos todo = new To_dos(roletxt.Text,combotype.Text,goaltxt.Text);
            todo.Show();
        }
    }
}
