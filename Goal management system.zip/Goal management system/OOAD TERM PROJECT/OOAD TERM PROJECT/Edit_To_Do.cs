﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOAD_TERM_PROJECT
{
    public partial class Edit_To_Do : Form
    {
        private ServiceReference1.To_Dos editpost = new ServiceReference1.To_Dos();
        private ServiceReference1.Service1Client server = new ServiceReference1.Service1Client();
        int index;
        public Edit_To_Do()
        {
            InitializeComponent();
        }

        public Edit_To_Do(ServiceReference1.To_Dos post, int a)
        {
            editpost = post;
            index = a;
            InitializeComponent();

        }
        private void Edit_To_Do_Load(object sender, EventArgs e)
        {

        }

        private void savebtn_Click(object sender, EventArgs e)
        {
            editpost.Todo = todotxt.Text;
            editpost.Date = datetxt.Text;
            server.Deletetodo(index);
            server.savetodo(editpost, index);
            this.Close();
            Role role = new Role();
            role.Show();

        }
    }
}
