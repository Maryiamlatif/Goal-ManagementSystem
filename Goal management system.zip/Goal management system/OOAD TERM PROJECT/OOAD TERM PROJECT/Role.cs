﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOAD_TERM_PROJECT
{
    public partial class Role : Form
    {
        public Role()
        {
            InitializeComponent();
            BindMethod();

        }
        public void BindMethod()
        {
            DataGridViewButtonColumn editButton = new DataGridViewButtonColumn();
            editButton.FlatStyle = FlatStyle.Popup;
            editButton.HeaderText = "Edit";
            editButton.Name = "Edit";
            editButton.UseColumnTextForButtonValue = true;
            editButton.Text = "Edit";
            editButton.Width = 60;
            if (dataGridView1.Columns.Contains(editButton.Name = "Edit"))
            {

            }
            else
            {
                dataGridView1.Columns.Add(editButton);
            }

            DataGridViewButtonColumn DeleteButton = new DataGridViewButtonColumn();
            DeleteButton.FlatStyle = FlatStyle.Popup;
            DeleteButton.HeaderText = "Delete";
            DeleteButton.Name = "Delete";
            DeleteButton.UseColumnTextForButtonValue = true;
            DeleteButton.Text = "Delete";
            DeleteButton.Width = 60;
            if (dataGridView1.Columns.Contains(DeleteButton.Name = "Delete"))
            {

            }
            else
            {
                dataGridView1.Columns.Add(DeleteButton);
            }

            DataGridViewButtonColumn AddGoal = new DataGridViewButtonColumn();
            AddGoal.FlatStyle = FlatStyle.Popup;
            AddGoal.HeaderText = "AddGoal";
            AddGoal.Name = "AddGoal";
            AddGoal.UseColumnTextForButtonValue = true;
            AddGoal.Text = "AddGoal";
            AddGoal.Width = 60;
            if (dataGridView1.Columns.Contains(AddGoal.Name = "AddGoal"))
            {

            }
            else
            {
                dataGridView1.Columns.Add(AddGoal);
            }
        }

        private void Role_Load(object sender, EventArgs e)
        {
            Datashow();
        }

        private void BTNaddrole_Click(object sender, EventArgs e)
        {
            ServiceReference1.Service1Client server = new ServiceReference1.Service1Client();
            ServiceReference1.Role role = new ServiceReference1.Role();
            role.Rolename = rolenametxt.Text;
            role.Roletype = combotype.Text;
            server.addrole(role);
            MessageBox.Show("Role Added successfully");
            Datashow();

            
        }
        public void Datashow()
        {
            ServiceReference1.Service1Client myclient = new ServiceReference1.Service1Client();
            BindingSource bds = new BindingSource();
            bds.DataSource = myclient.getrolelist();
            dataGridView1.DataSource = bds;
        }
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
               if(e.ColumnIndex == 0)
            {
                ServiceReference1.Service1Client server = new ServiceReference1.Service1Client();
                ServiceReference1.Role post = new ServiceReference1.Role();
                int index = e.RowIndex;
                post = server.getrole(index);
                 Edit edit = new Edit(post, index);
                 edit.Show();
                MessageBox.Show("Add Goal");


           
            }
               else if( e.ColumnIndex==1)
            {
                ServiceReference1.Service1Client server = new ServiceReference1.Service1Client();
                ServiceReference1.Role post = new ServiceReference1.Role();
                int index = e.RowIndex;
                server.DeleteRole(index);
                Datashow();

            }
               else if(e.ColumnIndex==2)
            {
                DataGridViewRow row = this.dataGridView1.Rows[e.RowIndex];
                ServiceReference1.Service1Client server = new ServiceReference1.Service1Client();
                ServiceReference1.Role post = new ServiceReference1.Role();
                int index = e.RowIndex;
                post = server.getrole(index);
                Goals goal = new Goals( post, index);
                goal.Show();
                MessageBox.Show("goals added successfully");
            }

        }

        private void btnRole_Click(object sender, EventArgs e)
        {
           
        }

        private void goalinkbtn_Click(object sender, EventArgs e)
        {
            Goals goal = new Goals(rolenametxt.Text,combotype.Text);
            goal.Show();
        }
    } 
}
