﻿namespace OOAD_TERM_PROJECT
{
    partial class Role
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.rolenametxt = new System.Windows.Forms.TextBox();
            this.combotype = new System.Windows.Forms.ComboBox();
            this.lblRoleName = new System.Windows.Forms.Label();
            this.lblRoleType = new System.Windows.Forms.Label();
            this.BTNaddrole = new System.Windows.Forms.Button();
            this.BTNreports = new System.Windows.Forms.Button();
            this.BTNtodolist = new System.Windows.Forms.Button();
            this.BTNGOAL = new System.Windows.Forms.Button();
            this.btnRole = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.goalinkbtn = new System.Windows.Forms.Button();
            this.roleBindingSource = new System.Windows.Forms.BindingSource(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.roleBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // rolenametxt
            // 
            this.rolenametxt.Location = new System.Drawing.Point(272, 65);
            this.rolenametxt.Name = "rolenametxt";
            this.rolenametxt.Size = new System.Drawing.Size(100, 20);
            this.rolenametxt.TabIndex = 0;
            this.rolenametxt.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // combotype
            // 
            this.combotype.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combotype.FormattingEnabled = true;
            this.combotype.Items.AddRange(new object[] {
            "Work",
            "Social",
            "Self"});
            this.combotype.Location = new System.Drawing.Point(272, 127);
            this.combotype.Name = "combotype";
            this.combotype.Size = new System.Drawing.Size(121, 21);
            this.combotype.TabIndex = 1;
            this.combotype.SelectedIndexChanged += new System.EventHandler(this.comboBox1_SelectedIndexChanged);
            // 
            // lblRoleName
            // 
            this.lblRoleName.AutoSize = true;
            this.lblRoleName.Location = new System.Drawing.Point(188, 67);
            this.lblRoleName.Name = "lblRoleName";
            this.lblRoleName.Size = new System.Drawing.Size(60, 13);
            this.lblRoleName.TabIndex = 2;
            this.lblRoleName.Text = "Role Name";
            // 
            // lblRoleType
            // 
            this.lblRoleType.AutoSize = true;
            this.lblRoleType.Location = new System.Drawing.Point(188, 137);
            this.lblRoleType.Name = "lblRoleType";
            this.lblRoleType.Size = new System.Drawing.Size(56, 13);
            this.lblRoleType.TabIndex = 3;
            this.lblRoleType.Text = "Role Type";
            // 
            // BTNaddrole
            // 
            this.BTNaddrole.Location = new System.Drawing.Point(272, 236);
            this.BTNaddrole.Name = "BTNaddrole";
            this.BTNaddrole.Size = new System.Drawing.Size(75, 23);
            this.BTNaddrole.TabIndex = 4;
            this.BTNaddrole.Text = "Add Role";
            this.BTNaddrole.UseVisualStyleBackColor = true;
            this.BTNaddrole.Click += new System.EventHandler(this.BTNaddrole_Click);
            // 
            // BTNreports
            // 
            this.BTNreports.Location = new System.Drawing.Point(23, 127);
            this.BTNreports.Name = "BTNreports";
            this.BTNreports.Size = new System.Drawing.Size(75, 23);
            this.BTNreports.TabIndex = 5;
            this.BTNreports.Text = "Reports";
            this.BTNreports.UseVisualStyleBackColor = true;
            // 
            // BTNtodolist
            // 
            this.BTNtodolist.Location = new System.Drawing.Point(23, 107);
            this.BTNtodolist.Name = "BTNtodolist";
            this.BTNtodolist.Size = new System.Drawing.Size(75, 23);
            this.BTNtodolist.TabIndex = 6;
            this.BTNtodolist.Text = "To Do List";
            this.BTNtodolist.UseVisualStyleBackColor = true;
            // 
            // BTNGOAL
            // 
            this.BTNGOAL.Location = new System.Drawing.Point(23, 86);
            this.BTNGOAL.Name = "BTNGOAL";
            this.BTNGOAL.Size = new System.Drawing.Size(75, 23);
            this.BTNGOAL.TabIndex = 7;
            this.BTNGOAL.Text = "Goal";
            this.BTNGOAL.UseVisualStyleBackColor = true;
            // 
            // btnRole
            // 
            this.btnRole.BackColor = System.Drawing.SystemColors.ControlDarkDark;
            this.btnRole.Location = new System.Drawing.Point(23, 62);
            this.btnRole.Name = "btnRole";
            this.btnRole.Size = new System.Drawing.Size(75, 23);
            this.btnRole.TabIndex = 8;
            this.btnRole.Text = "Role";
            this.btnRole.UseVisualStyleBackColor = false;
            this.btnRole.Click += new System.EventHandler(this.btnRole_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Location = new System.Drawing.Point(498, 65);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(466, 274);
            this.dataGridView1.TabIndex = 9;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(458, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(59, 24);
            this.label1.TabIndex = 10;
            this.label1.Text = "Role ";
            // 
            // goalinkbtn
            // 
            this.goalinkbtn.Location = new System.Drawing.Point(295, 350);
            this.goalinkbtn.Name = "goalinkbtn";
            this.goalinkbtn.Size = new System.Drawing.Size(222, 23);
            this.goalinkbtn.TabIndex = 23;
            this.goalinkbtn.Text = "Click here to go to the Goal Form";
            this.goalinkbtn.UseVisualStyleBackColor = true;
            this.goalinkbtn.Click += new System.EventHandler(this.goalinkbtn_Click);
            // 
            // roleBindingSource
            // 
            this.roleBindingSource.DataSource = typeof(OOAD_TERM_PROJECT.Role);
            // 
            // Role
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1069, 543);
            this.Controls.Add(this.goalinkbtn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.btnRole);
            this.Controls.Add(this.BTNGOAL);
            this.Controls.Add(this.BTNtodolist);
            this.Controls.Add(this.BTNreports);
            this.Controls.Add(this.BTNaddrole);
            this.Controls.Add(this.lblRoleType);
            this.Controls.Add(this.lblRoleName);
            this.Controls.Add(this.combotype);
            this.Controls.Add(this.rolenametxt);
            this.Name = "Role";
            this.Text = "Role";
            this.Load += new System.EventHandler(this.Role_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.roleBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox rolenametxt;
        private System.Windows.Forms.ComboBox combotype;
        private System.Windows.Forms.Label lblRoleName;
        private System.Windows.Forms.Label lblRoleType;
        private System.Windows.Forms.Button BTNaddrole;
        private System.Windows.Forms.Button BTNreports;
        private System.Windows.Forms.Button BTNtodolist;
        private System.Windows.Forms.Button BTNGOAL;
        private System.Windows.Forms.Button btnRole;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.BindingSource roleBindingSource;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button goalinkbtn;
    }
}