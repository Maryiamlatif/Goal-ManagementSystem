﻿namespace OOAD_TERM_PROJECT
{
    partial class Edit
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.rolenametxt = new System.Windows.Forms.TextBox();
            this.rolenamelbl = new System.Windows.Forms.Label();
            this.roletypelbl = new System.Windows.Forms.Label();
            this.combotxt = new System.Windows.Forms.ComboBox();
            this.Savebtn = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // rolenametxt
            // 
            this.rolenametxt.Location = new System.Drawing.Point(155, 33);
            this.rolenametxt.Name = "rolenametxt";
            this.rolenametxt.Size = new System.Drawing.Size(100, 20);
            this.rolenametxt.TabIndex = 0;
            // 
            // rolenamelbl
            // 
            this.rolenamelbl.AutoSize = true;
            this.rolenamelbl.Location = new System.Drawing.Point(44, 39);
            this.rolenamelbl.Name = "rolenamelbl";
            this.rolenamelbl.Size = new System.Drawing.Size(60, 13);
            this.rolenamelbl.TabIndex = 1;
            this.rolenamelbl.Text = "Role Name";
            // 
            // roletypelbl
            // 
            this.roletypelbl.AutoSize = true;
            this.roletypelbl.Location = new System.Drawing.Point(44, 83);
            this.roletypelbl.Name = "roletypelbl";
            this.roletypelbl.Size = new System.Drawing.Size(56, 13);
            this.roletypelbl.TabIndex = 2;
            this.roletypelbl.Text = "Role Type";
            // 
            // combotxt
            // 
            this.combotxt.FormattingEnabled = true;
            this.combotxt.Location = new System.Drawing.Point(155, 80);
            this.combotxt.Name = "combotxt";
            this.combotxt.Size = new System.Drawing.Size(121, 21);
            this.combotxt.TabIndex = 3;
            // 
            // Savebtn
            // 
            this.Savebtn.Location = new System.Drawing.Point(171, 144);
            this.Savebtn.Name = "Savebtn";
            this.Savebtn.Size = new System.Drawing.Size(75, 23);
            this.Savebtn.TabIndex = 4;
            this.Savebtn.Text = "Save";
            this.Savebtn.UseVisualStyleBackColor = true;
            this.Savebtn.Click += new System.EventHandler(this.Savebtn_Click);
            // 
            // Edit
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 261);
            this.Controls.Add(this.Savebtn);
            this.Controls.Add(this.combotxt);
            this.Controls.Add(this.roletypelbl);
            this.Controls.Add(this.rolenamelbl);
            this.Controls.Add(this.rolenametxt);
            this.Name = "Edit";
            this.Text = "Edit";
            this.Load += new System.EventHandler(this.Edit_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox rolenametxt;
        private System.Windows.Forms.Label rolenamelbl;
        private System.Windows.Forms.Label roletypelbl;
        private System.Windows.Forms.ComboBox combotxt;
        private System.Windows.Forms.Button Savebtn;
    }
}