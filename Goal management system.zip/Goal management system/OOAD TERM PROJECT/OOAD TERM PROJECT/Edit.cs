﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOAD_TERM_PROJECT
{
    public partial class Edit : Form
    {
        private ServiceReference1.Role editpost = new ServiceReference1.Role();
        private ServiceReference1.Service1Client server = new ServiceReference1.Service1Client();
        int index;
        public Edit()
        {
            InitializeComponent();
        }
        public Edit(ServiceReference1.Role post,int a)
        {
            editpost = post;
            index = a;
            InitializeComponent();

        }


        private void Edit_Load(object sender, EventArgs e)
        {
            rolenametxt.Text = editpost.Rolename;
            combotxt.Text = editpost.Roletype;

        }

        private void Savebtn_Click(object sender, EventArgs e)
        {
            editpost.Rolename = rolenametxt.Text;
            editpost.Roletype = combotxt.Text;
            server.DeleteRole(index);
            server.savepost(editpost, index);
            this.Close();
            Role role = new Role();
            role.Show();

        }
    }
}
