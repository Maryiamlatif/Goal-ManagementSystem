﻿namespace OOAD_TERM_PROJECT
{
    partial class To_dos
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnRole = new System.Windows.Forms.Button();
            this.BTNtodolist = new System.Windows.Forms.Button();
            this.BTNreports = new System.Windows.Forms.Button();
            this.goalbtn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.goaltxt = new System.Windows.Forms.TextBox();
            this.rolenametxt = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.todotxt = new System.Windows.Forms.TextBox();
            this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
            this.datetxt = new System.Windows.Forms.TextBox();
            this.addtodobtn = new System.Windows.Forms.Button();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.combotype = new System.Windows.Forms.ComboBox();
            this.label5 = new System.Windows.Forms.Label();
            this.Column1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Column2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnRole
            // 
            this.btnRole.Location = new System.Drawing.Point(12, 25);
            this.btnRole.Name = "btnRole";
            this.btnRole.Size = new System.Drawing.Size(75, 23);
            this.btnRole.TabIndex = 16;
            this.btnRole.Text = "Role";
            this.btnRole.UseVisualStyleBackColor = true;
            // 
            // BTNtodolist
            // 
            this.BTNtodolist.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.BTNtodolist.Location = new System.Drawing.Point(12, 70);
            this.BTNtodolist.Name = "BTNtodolist";
            this.BTNtodolist.Size = new System.Drawing.Size(75, 23);
            this.BTNtodolist.TabIndex = 14;
            this.BTNtodolist.Text = "To Do List";
            this.BTNtodolist.UseVisualStyleBackColor = true;
            this.BTNtodolist.Click += new System.EventHandler(this.BTNtodolist_Click);
            // 
            // BTNreports
            // 
            this.BTNreports.Location = new System.Drawing.Point(12, 90);
            this.BTNreports.Name = "BTNreports";
            this.BTNreports.Size = new System.Drawing.Size(75, 23);
            this.BTNreports.TabIndex = 13;
            this.BTNreports.Text = "Reports";
            this.BTNreports.UseVisualStyleBackColor = true;
            // 
            // goalbtn
            // 
            this.goalbtn.Location = new System.Drawing.Point(12, 47);
            this.goalbtn.Name = "goalbtn";
            this.goalbtn.Size = new System.Drawing.Size(75, 23);
            this.goalbtn.TabIndex = 17;
            this.goalbtn.Text = "Goal";
            this.goalbtn.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(214, 52);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(29, 13);
            this.label1.TabIndex = 18;
            this.label1.Text = "Goal";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(214, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(57, 13);
            this.label2.TabIndex = 19;
            this.label2.Text = "RoleName";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(214, 120);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(31, 13);
            this.label3.TabIndex = 20;
            this.label3.Text = "Type";
            // 
            // goaltxt
            // 
            this.goaltxt.Location = new System.Drawing.Point(303, 45);
            this.goaltxt.Name = "goaltxt";
            this.goaltxt.Size = new System.Drawing.Size(100, 20);
            this.goaltxt.TabIndex = 21;
            // 
            // rolenametxt
            // 
            this.rolenametxt.Location = new System.Drawing.Point(303, 77);
            this.rolenametxt.Name = "rolenametxt";
            this.rolenametxt.Size = new System.Drawing.Size(100, 20);
            this.rolenametxt.TabIndex = 22;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(214, 161);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(37, 13);
            this.label4.TabIndex = 24;
            this.label4.Text = "To Do";
            // 
            // todotxt
            // 
            this.todotxt.Location = new System.Drawing.Point(303, 158);
            this.todotxt.Name = "todotxt";
            this.todotxt.Size = new System.Drawing.Size(100, 20);
            this.todotxt.TabIndex = 25;
            // 
            // dateTimePicker1
            // 
            this.dateTimePicker1.CustomFormat = "dd-MM-yyyy";
            this.dateTimePicker1.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker1.Location = new System.Drawing.Point(303, 232);
            this.dateTimePicker1.Name = "dateTimePicker1";
            this.dateTimePicker1.Size = new System.Drawing.Size(200, 20);
            this.dateTimePicker1.TabIndex = 26;
            // 
            // datetxt
            // 
            this.datetxt.Location = new System.Drawing.Point(303, 190);
            this.datetxt.Name = "datetxt";
            this.datetxt.Size = new System.Drawing.Size(100, 20);
            this.datetxt.TabIndex = 27;
            // 
            // addtodobtn
            // 
            this.addtodobtn.Location = new System.Drawing.Point(303, 295);
            this.addtodobtn.Name = "addtodobtn";
            this.addtodobtn.Size = new System.Drawing.Size(75, 23);
            this.addtodobtn.TabIndex = 28;
            this.addtodobtn.Text = "Add todo";
            this.addtodobtn.UseVisualStyleBackColor = true;
            this.addtodobtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Column1,
            this.Column2});
            this.dataGridView1.Location = new System.Drawing.Point(527, 12);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(446, 319);
            this.dataGridView1.TabIndex = 29;
            this.dataGridView1.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView1_CellContentClick);
            // 
            // combotype
            // 
            this.combotype.FormattingEnabled = true;
            this.combotype.Items.AddRange(new object[] {
            "social",
            "work",
            "self"});
            this.combotype.Location = new System.Drawing.Point(303, 120);
            this.combotype.Name = "combotype";
            this.combotype.Size = new System.Drawing.Size(121, 21);
            this.combotype.TabIndex = 30;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(214, 197);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 13);
            this.label5.TabIndex = 31;
            this.label5.Text = "Calender";
            // 
            // Column1
            // 
            this.Column1.HeaderText = "Edit";
            this.Column1.Name = "Column1";
            // 
            // Column2
            // 
            this.Column2.HeaderText = "Delete";
            this.Column2.Name = "Column2";
            // 
            // To_dos
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(985, 367);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.combotype);
            this.Controls.Add(this.dataGridView1);
            this.Controls.Add(this.addtodobtn);
            this.Controls.Add(this.datetxt);
            this.Controls.Add(this.dateTimePicker1);
            this.Controls.Add(this.todotxt);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.rolenametxt);
            this.Controls.Add(this.goaltxt);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.goalbtn);
            this.Controls.Add(this.btnRole);
            this.Controls.Add(this.BTNtodolist);
            this.Controls.Add(this.BTNreports);
            this.Name = "To_dos";
            this.Text = "To_dos";
            this.Load += new System.EventHandler(this.To_dos_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnRole;
        private System.Windows.Forms.Button BTNtodolist;
        private System.Windows.Forms.Button BTNreports;
        private System.Windows.Forms.Button goalbtn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox goaltxt;
        private System.Windows.Forms.TextBox rolenametxt;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox todotxt;
        private System.Windows.Forms.DateTimePicker dateTimePicker1;
        private System.Windows.Forms.TextBox datetxt;
        private System.Windows.Forms.Button addtodobtn;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.ComboBox combotype;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Column2;
    }
}