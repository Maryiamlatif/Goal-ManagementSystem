﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace OOAD_TERM_PROJECT
{
    public partial class SignUP : Form
    {
        public SignUP()
        {
            InitializeComponent();
        }

        private void BTNlogin_Click(object sender, EventArgs e)
        {
            ServiceReference1.Service1Client server = new ServiceReference1.Service1Client();
            ServiceReference1.UserDetail newuser = new ServiceReference1.UserDetail();
            newuser.Username = textBox1.Text;
            newuser.Password = textBox2.Text;
            server.Adduser(newuser);
            MessageBox.Show("Signupp successfully");

       
        }

        private void button1_Click(object sender, EventArgs e)
        {
            SignUP form = new SignUP();
            form.Show();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void linkrole_Click(object sender, EventArgs e)
        {
            Role role = new Role();
            role.Show();

        }
    }
}
