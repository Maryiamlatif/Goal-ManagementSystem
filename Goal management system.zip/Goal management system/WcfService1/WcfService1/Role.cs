﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WcfService1
{
    public class Role
    {
        private string rolename;
        private string roletype;

        public string Rolename
        {
            get
            {
                return rolename;
            }

            set
            {
                rolename = value;
            }
        }

        public string Roletype
        {
            get
            {
                return roletype;
            }

            set
            {
                roletype = value;
            }
        }
    }
}