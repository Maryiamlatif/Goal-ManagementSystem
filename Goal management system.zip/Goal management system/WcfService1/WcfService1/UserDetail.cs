﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WcfService1
{
    public class UserDetail
    {
       public static int indexcount;
        public string  username;
       public string   password;

        public string Username
        {
            get
            {
                return username;
            }

            set
            {
                username = value;
            }
        }

        public string Password
        {
            get
            {
                return password;
            }

            set
            {
                password = value;
            }
        }

        public static int Indexcount
        {
            get
            {
                return indexcount;
            }

            set
            {
                indexcount = value;
            }
        }
    }
}