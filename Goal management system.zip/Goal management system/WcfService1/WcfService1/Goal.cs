﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WcfService1
{
    public class Goal
    {
        private string goalname;
       private string Type1;


        public string Goalname
        {
            get
            {
                return goalname;
            }

            set
            {
                goalname = value;
            }
        }

        public string Type11
        {
            get
            {
                return Type1;
            }

            set
            {
                Type1 = value;
            }
        }
    }
        }
    