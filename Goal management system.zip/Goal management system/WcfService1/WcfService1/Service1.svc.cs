﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace WcfService1
{

    // NOTE: You can use the "Rename" command on the "Refactor" menu to change the class name "Service1" in code, svc and config file together.
    // NOTE: In order to launch WCF Test Client for testing this service, please select Service1.svc or Service1.svc.cs at the Solution Explorer and start debugging.
    public class Service1 : IService1
    {
        public string GetData(int value)
        {
            return string.Format("You entered: {0}", value);
        }

        public void Adduser(UserDetail user)
        {
            User.data.Add(user);
        }
        public List<Role> getrolelist()
        {
            return User.role1;
        }
       public void addrole(Role  roles)
        {
            User.role1.Add(roles);
        }
        public List<Goal> getgoalist()
        {
            return User.minegoals;
        }
     public   Role getrole(int index)
        {
            return User.role1[index];
        }
        public To_Dos gettodo(int index)
        {
            return User.to_do[index];
        }
        public void DeleteRole(int index)
        {
            User.role1.RemoveAt(index);
        }
        public void Deletetodo(int index)
        {
            User.to_do.RemoveAt(index);
        }
        public  void savepost(Role post , int index)
        {
            //User.role1.RemoveAt(index);
            User.role1.Insert( index,post);
        }
        public void savetodo(To_Dos post, int index)
        {
            User.to_do.Insert(index, post);
        }
        public void addgoal(Goal goals)
        {
            User.minegoals.Add(goals);
        }
      public  void addtodos (To_Dos todo)
        {
            User.to_do.Add(todo);
        }
        public List<To_Dos> gettodoslist()
        {
            return User.to_do;
        }
        /*public bool searchuser(string name, string password)
        {
            for (int i = 0; i < UserDetail.indexcount; i++)
                if (UserDetail.username[i] == name && UserDetail.password[i] == password)
                    return true;
                else
                   return false;
        }*/
        public CompositeType GetDataUsingDataContract(CompositeType composite)
        {
            if (composite == null)
            {
                throw new ArgumentNullException("composite");
            }
            if (composite.BoolValue)
            {
                composite.StringValue += "Suffix";
            }
            return composite;
        }
    }
}
