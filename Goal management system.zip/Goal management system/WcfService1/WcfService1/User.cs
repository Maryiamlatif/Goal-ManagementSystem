﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WcfService1
{
    public class User
    {
        public static  int indexcount;
        public static List<UserDetail> data  = new List<UserDetail>();
        public static List<Role> role1 = new List<Role>();
        public static List<Goal> minegoals = new List<Goal>();
        public static List<To_Dos> to_do = new List<To_Dos>();
    }
} 