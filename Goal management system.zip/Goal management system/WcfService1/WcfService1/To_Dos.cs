﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WcfService1
{
    public class To_Dos
    {
        private string todo;
        private string date;

        public string Todo
        {
            get
            {
                return todo;
            }

            set
            {
                todo = value;
            }
        }

        public string Date
        {
            get
            {
                return date;
            }

            set
            {
                date = value;
            }
        }
    }
}